﻿var coeffs = Console.ReadLine().Split().Select(double.Parse).ToArray();
if (coeffs.Length == 3)
{
    double a = coeffs[0], b = coeffs[1], c = coeffs[2];
    double d = b * b - 4 * a * c;
    if (d > 0)
        Console.WriteLine($"{(-b + Math.Sqrt(d)) / (2 * a)} {(-b - Math.Sqrt(d)) / (2 * a)}");
    else if (d == 0)
        Console.WriteLine($"{-b / (2 * a)}");
    else
        Console.WriteLine("Няма реални корени");
}