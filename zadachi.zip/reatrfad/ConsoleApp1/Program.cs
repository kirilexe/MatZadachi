﻿Console.Write("Въведи число: ");
string number = Console.ReadLine();
Console.Write("От коя бройна система: ");
int fromBase = int.Parse(Console.ReadLine());
Console.Write("Към коя бройна система: ");
int toBase = int.Parse(Console.ReadLine());
string converted = Convert.ToString(Convert.ToInt32(number, fromBase), toBase);
Console.WriteLine(converted);