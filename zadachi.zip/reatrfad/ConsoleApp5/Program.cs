﻿int n = int.Parse(Console.ReadLine());
double minLen = double.MaxValue;
for (int i = 0; i < n; i++)
{
    var vec = Console.ReadLine().Split().Select(double.Parse).ToArray();
    double len = Math.Sqrt(vec[0] * vec[0] + vec[1] * vec[1] + vec[2] * vec[2]);
    if (len < minLen) minLen = len;
}
Console.WriteLine(minLen);