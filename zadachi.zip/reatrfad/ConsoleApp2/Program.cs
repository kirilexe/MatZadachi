﻿var nums = Console.ReadLine().Split().Select(double.Parse).ToList();
var avg = nums.Average();
var mode = nums.GroupBy(x => x).OrderByDescending(g => g.Count()).First().Key;
var med = nums.OrderBy(x => x).ToList();
double median = med.Count % 2 == 0 ? (med[med.Count / 2 - 1] + med[med.Count / 2]) / 2.0 : med[med.Count / 2];
Console.WriteLine($"{avg:F2} / {mode} / {median}");